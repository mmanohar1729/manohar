MANOHAR PORTFOLIO WEBSITE

Files:
- index.html = complete website
- qrcode.png = QR code

IMPORTANT:
The QR code currently contains:
https://YOUR-USERNAME.github.io/manohar-portfolio/

After you publish the site on GitHub Pages, replace the QR code with your real published URL.

To test the website:
1. Open index.html in Chrome.
2. For a public website, upload the files to a GitHub repository and enable GitHub Pages.
